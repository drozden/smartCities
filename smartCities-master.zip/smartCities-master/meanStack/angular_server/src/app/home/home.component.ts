import { Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from '../shared/user.service';
import { User } from '../shared/user.model';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { UserProfileComponent } from '../user-profile/user-profile.component';
import { Chart } from 'chart.js';


var dataPoints = [{  
    x: 1,  
    y: 10
},{  
    x: 2,  
    y: 20
},{
    x: 3,
    y: 15
}];

var labels = ["X-Values", "Y-Values"]

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  @ViewChild('lineChart') private chartRef;
  chart: any;
  localUser;
  inputCode: string;
  DialogComponentRef: MatDialogRef<UserProfileComponent>;

  constructor(private userService: UserService, private dialog: MatDialog){ }

  ngOnInit() {
    this.userService.getUserProfile().subscribe(
      res => {
        this.localUser = res['user'];
      },
      err => { 
        console.log(err);
        
      }
    );

    this.chart = new Chart(this.chartRef.nativeElement, {
      type: 'line',
      data: {
        labels: labels, // your labels array
        datasets: [
          {
            data: dataPoints, // your data array
            borderColor: '#00AEFF',
            fill: false
          }
        ]
      },
      options: {
        legend: {
          display: false
        },
        scales: {
          xAxes: [{
            display: true
          }],
          yAxes: [{
            display: true
          }],
        }
      }
    });
  }

  run(){
    var editor = <any>document.querySelector(".CodeMirror");
    var editor1 = editor.CodeMirror.getValue();
    console.log(editor1);
    (document.getElementById("output") as HTMLInputElement).value = editor1;
  }

  

  openDialog() {

    const dialogConfig = new MatDialogConfig();
    
    dialogConfig.autoFocus = true;
    dialogConfig.disableClose = true;
    dialogConfig.hasBackdrop = true;
    dialogConfig.panelClass = 'myDialog';
    dialogConfig.backdropClass = 'myDialog';
    //dialogConfig.backdropClass = '.cdk-overlay-backdrop';
    this.dialog.open(UserProfileComponent, dialogConfig);
    //this.dialog.open(UserProfileComponent, {panelClass: 'myDialog'});
  }
}