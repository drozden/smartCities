import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/user.service';
import { Router } from "@angular/router";

import { MatDialog, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  userDetails;
  DialogComponentRef: MatDialogRef<UserProfileComponent>
  constructor(private userService: UserService, private router: Router, private dialog: MatDialog) { }

  ngOnInit() {
    this.userService.getUserProfile().subscribe(
      res => {
        this.userDetails = res['user'];
      },
      err => { 
        console.log(err);
        
      }
    );
  }

  onModify(){
    document.getElementById('infochange').style.display ="block";
  }

  onLogout(){
    this.dialog.closeAll();
    this.userService.deleteToken();
    this.router.navigate(['/login']);
  }

  onClose(){
    this.dialog.closeAll();
  }
  
}
