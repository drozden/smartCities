import { Component, OnInit } from '@angular/core';
import { Reading } from '../reading';
import { ReadingService } from '../reading.service';

@Component({
  selector: 'app-my-line-chart',
  templateUrl: './my-line-chart.component.html',
  styleUrls: ['./my-line-chart.component.css'],
  providers: [ReadingService]
})
export class MyLineChartComponent implements OnInit {

  readings: Array<Reading>;


  // readings: Reading[] = [
  //   {"_id":"5e8a968694828788ec89f475","timestamp":"2020-04-06T02:40:06.715Z","device_id":"lamar","temp":20.67765625,"humidity":49.69437774546112,"gas":100734,"pressure":1008.3687807149389},
  //   {"_id":"5e8a966894828788ec89f474","timestamp":"2020-04-06T02:39:36.486Z","device_id":"lamar","temp":20.68078125,"humidity":49.69476205224229,"gas":100194,"pressure":1008.3638652454266}
  // ];

  //public lineChartLabels = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  //public lineChartData = [{data: [65, 59, 80, 81, 56, 55, 57, 85]}]

  public lineChartLabels = [];
  public lineChartData = [{data:[], label:""}];

  public lineChartOptions = {
    //scaleShowVerticalLines: false,
    responsive: true,
    title: {
      display: true,
      text: 'Tech Pointe Temperature',
      fontSize: 25
    },
    scales: { //you're missing this
      yAxes: [{
         scaleLabel: {
            display: true,
            labelString: 'Temperature (°C)',
            fontSize: 15
         }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Timestamp',
          fontSize: 15
       }
      }]
   }//END scales
  };

  public lineChartLegend = false; // use if different types of data needs to be displayed
  public lineChartType = 'line';

  public isDataAvailable: boolean; // use this if you want to hold off on displaying chart
  ngOnInit() {
    this._readingService.getReadings()
    .subscribe( res => {
      this.readings = res;
      console.log(this.readings);
      // this.lineChartData = [
      //   {data: [this.readings[0].pressure, this.readings[1].pressure], label: "Pressure"},
      //   {data: [this.readings[0].temp, this.readings[1].temp], label: "Temperature"},
      //   {data: [this.readings[0].gas, this.readings[1].gas], label: "Gas"},
      //   {data: [this.readings[0].humidity, this.readings[1].humidity], label: "Humidity"}
      // ];
      // this.lineChartLabels = [this.readings[0].timestamp, this.readings[1].timestamp];
      let chart_data = [];
      for (let i = 0; i < this.readings.length; i++){
        chart_data.push(this.readings[i].temp);
        this.lineChartLabels.push(this.readings[i].timestamp);
      }
      this.lineChartData = [{data: chart_data, label:"Temperature (°C)"}];
      this.isDataAvailable = true; // allow LineChartComponent to render
    });

  }

  constructor(private _readingService: ReadingService) {}

}
