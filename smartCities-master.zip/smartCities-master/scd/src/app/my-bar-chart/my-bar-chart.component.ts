import { Component, OnInit } from '@angular/core';
import { Reading } from '../reading';

@Component({
  selector: 'app-my-bar-chart',
  templateUrl: './my-bar-chart.component.html',
  styleUrls: ['./my-bar-chart.component.css']
})
export class MyBarChartComponent implements OnInit {

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };


  // readings: Reading[] = [
  //   {"_id":"5e8a968694828788ec89f475","timestamp":"2020-04-06T02:40:06.715Z","device_id":"lamar","temp":20.67765625,"humidity":49.69437774546112,"gas":100734,"pressure":1008.3687807149389},
  //   {"_id":"5e8a966894828788ec89f474","timestamp":"2020-04-06T02:39:36.486Z","device_id":"lamar","temp":20.68078125,"humidity":49.69476205224229,"gas":100194,"pressure":1008.3638652454266}
  // ];

  public barChartLabels = ['2006','2007','2008','2009','2010','2011','2012','2013'];
  public barChartType = 'bar';
  public barChartLegend = true;

  public barChartData = [
    {data: [65, 59, 80, 81, 56, 55, 57, 85], label: "Series A"}
    //{data: [28, 27, 33, 49, 91, 22, 41], label: "Series B"}
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
