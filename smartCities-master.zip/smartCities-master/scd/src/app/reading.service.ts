import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Reading } from './reading';

@Injectable({
  providedIn: 'root'
})
export class ReadingService {
  private _getUrl = "/api";
  constructor(private _http: HttpClient) { }

   getReadings(){
    return this._http.get<Reading[]>(this._getUrl);
  }
}
