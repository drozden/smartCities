// interface EnumDataItem {
//   temp: number; humidity: number; gas: number; pressure: number;
// }

import { Time } from '@angular/common';

//interface EnumDataItems extends Array<EnumDataItem>{}

export class Reading{
  _id:string;
    //temp: Number,
  // humidity: Number,
  // gas: Number,
  // pressure: Number,
  timestamp: string;
  device_id: string;
  temp: number;
  humidity: number;
  gas: number;
  pressure: number;
}
